# -*- coding: utf-8 -*-
# Module: default
# Author: Roman V. M.
# Created on: 28.11.2014
# License: GPL v.3 https://www.gnu.org/copyleft/gpl.html

import sys
from urllib import urlencode
from urlparse import parse_qsl
import xbmcgui
import xbmcplugin

# Get the plugin url in plugin:// notation.
_url = sys.argv[0]
# Get the plugin handle as an integer number.
_handle = int(sys.argv[1])

# Free sample videos are provided by www.vidsplay.com
# Here we use a fixed set of properties simply for demonstrating purposes
# In a "real life" plugin you will need to get info and links to video files/streams
# from some web-site or online service.
VIDEOS = {'喜劇': [{'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我最糟糕的噩梦',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546402246.jpg',
                       'video': 'https://cdn.youku-letv.com/20190101/13861_03b87695/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '纽约两日情',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546401422.jpg',
                       'video': 'https://cdn.youku-letv.com/20190101/13856_3ca8abc9/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '临床爱情教学',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546393861.jpg',
                       'video': 'https://cdn.youku-letv.com/20190101/13853_dfb464eb/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '爱之咬痕',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546390361.jpg',
                       'video': 'https://cdn.youku-letv.com/20190101/13848_e91481dc/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '雪怪大冒险',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-10-03/201810031538548909.jpg',
                       'video': 'https://bobo.kukucdn.com/20190101/3264_ce12d5ef/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '三个老枪手',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-05-28/201805281527473347.jpg',
                       'video': 'https://bobo.kukucdn.com/20190101/3266_7998a56f/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '救世主杰夫',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-01/201901011546344311.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16244_5c259637/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '好汉三条半',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-01/201901011546330295.jpg',
                       'video': 'https://52dy.hanju2017.com/20181231/16235_208bfd5b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '涉外大饭店',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-01/201901011546302943.jpg',
                       'video': 'https://cdn.youku-letv.com/20181231/13738_82f597b1/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '可疑的顾客们',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-01/201901011546302559.jpg',
                       'video': 'https://cdn.youku-letv.com/20181231/13736_04a58515/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '老人和枪',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-12-31/201812311546243127.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '无敌破坏王2：大闹互联网',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-24/201811241543031314.jpg',
                       'video': 'https://cdn.youku-letv.com/20181230/13673_e8173fe7/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '意外人生',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-12-31/201812311546227757.jpg',
                       'video': 'https://cdn.youku-letv.com/20181230/13661_124b1d80/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '真的不骗你3',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-12-31/201812311546227974.jpg',
                       'video': 'https://cdn.youku-letv.com/20181230/13662_de923266/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '妈妈的使命',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-12-30/201812301546149540.jpg',
                       'video': 'https://52dy.hanju2017.com/20181229/16201_95485db2/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '年度教师',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-12-30/201812301546149467.jpg',
                       'video': 'https://52dy.hanju2017.com/20181229/16200_69130688/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '修补生活',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-12-30/201812301546149229.jpg',
                       'video': 'https://52dy.hanju2017.com/20181229/16197_45f0a1bb/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '一部喜剧',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-12-30/201812301546149160.jpg',
                       'video': 'https://52dy.hanju2017.com/20181229/16196_a0c3bb5b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '那狗那猫',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-12-30/201812301546130139.jpg',
                       'video': 'https://cdn.youku-letv.com/20181229/13591_ba9901fd/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '断片之险途夺宝',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-12-29/201812291546091069.jpg',
                       'video': 'https://cdn.youku-letv.com/20181229/13556_88d030e0/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '黑衣女人',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-12-29/201812291546089382.jpg',
                       'video': 'https://52dy.hanju2017.com/20181229/16173_3ebddb00/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '社交动物',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-12-29/201812291546089274.jpg',
                       'video': 'https://52dy.hanju2017.com/20181229/16172_885cc415/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '深宫碟影',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-12-29/201812291546072590.jpg',
                       'video': 'https://52dy.hanju2017.com/20181228/16170_decaf8c7/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '敦煌不了情',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-12-29/201812291546072500.jpg',
                       'video': 'https://52dy.hanju2017.com/20181228/16171_aac2bc5d/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '争钱斗爱ATM',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-12-29/201812291546064484.jpg',
                       'video': 'https://cdn.youku-letv.com/20181228/13540_0b0858d2/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '我想戴上戒指',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-12-29/201812291546062696.jpg',
                       'video': 'https://cdn.youku-letv.com/20181228/13536_d357878f/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '巴雷利的巴菲',
                       'thumb': 'http://wx1.sinaimg.cn/mw690/e94ebbbcly1fljyjt54nhj20i70mr4qp.jpg',
                       'video': 'https://cdn.kuyunbo.club/20171116/CwrTKVpH/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '山的那一边',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-12-27/201812271545926355.jpg',
                       'video': 'https://37.rdeb.io/d/EERBIIAM5KVKO/%E5%B1%B1%E7%9A%84%E9%82%A3%E4%B8%80%E8%BE%B9.Hidden.Treasures.in.the.Mountain.2018.HD1080P.X264.AAC.Mandarin.CHT.mp4',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
				   {'name': '我的冤家是条狗',
                       'thumb': 'http://img.5252zy.com/upload/vod/2018-11-06/201811061541494120.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16275_55559fe3/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '黑疯婆子的万圣节',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546417399.jpg',
                       'video': 'https://52dy.hanju2017.com/20190101/16268_a905d56b/index.m3u8',
                       'genre': '喜劇'},
                   {'name': '双枪男人',
                       'thumb': 'http://img.5252zy.com/upload/vod/2019-01-02/201901021546401948.jpg',
                       'video': 'https://cdn.youku-letv.com/20190101/13859_c210f3e8/index.m3u8',
                       'genre': '喜劇'}
                      ],
            'Drama': [{'name': 'Postal Truck',
                      'thumb': 'http://www.vidsplay.com/wp-content/uploads/2017/05/us_postal-screenshot.jpg',
                      'video': 'http://www.vidsplay.com/wp-content/uploads/2017/05/us_postal.mp4',
                      'genre': 'Drama'},
                     {'name': 'Traffic',
                      'thumb': 'http://www.vidsplay.com/wp-content/uploads/2017/05/traffic1-screenshot.jpg',
                      'video': 'http://www.vidsplay.com/wp-content/uploads/2017/05/traffic1.mp4',
                      'genre': 'Drama'},
                     {'name': 'Traffic Arrows',
                      'thumb': 'http://www.vidsplay.com/wp-content/uploads/2017/05/traffic_arrows-screenshot.jpg',
                      'video': 'http://www.vidsplay.com/wp-content/uploads/2017/05/traffic_arrows.mp4',
                      'genre': 'Drama'}
                     ],
            'Food': [{'name': 'Chicken',
                      'thumb': 'http://www.vidsplay.com/wp-content/uploads/2017/05/bbq_chicken-screenshot.jpg',
                      'video': 'http://www.vidsplay.com/wp-content/uploads/2017/05/bbqchicken.mp4',
                      'genre': 'Food'},
                     {'name': 'Hamburger',
                      'thumb': 'http://www.vidsplay.com/wp-content/uploads/2017/05/hamburger-screenshot.jpg',
                      'video': 'http://www.vidsplay.com/wp-content/uploads/2017/05/hamburger.mp4',
                      'genre': 'Food'},
                     {'name': 'Pizza',
                      'thumb': 'http://www.vidsplay.com/wp-content/uploads/2017/05/pizza-screenshot.jpg',
                      'video': 'http://www.vidsplay.com/wp-content/uploads/2017/05/pizza.mp4',
                      'genre': 'Food'}
                     ]}


def get_url(**kwargs):
    """
    Create a URL for calling the plugin recursively from the given set of keyword arguments.

    :param kwargs: "argument=value" pairs
    :type kwargs: dict
    :return: plugin call URL
    :rtype: str
    """
    return '{0}?{1}'.format(_url, urlencode(kwargs))


def get_categories():
    """
    Get the list of video categories.

    Here you can insert some parsing code that retrieves
    the list of video categories (e.g. 'Movies', 'TV-shows', 'Documentaries' etc.)
    from some site or server.

    .. note:: Consider using `generator functions <https://wiki.python.org/moin/Generators>`_
        instead of returning lists.

    :return: The list of video categories
    :rtype: types.GeneratorType
    """
    return VIDEOS.iterkeys()


def get_videos(category):
    """
    Get the list of videofiles/streams.

    Here you can insert some parsing code that retrieves
    the list of video streams in the given category from some site or server.

    .. note:: Consider using `generators functions <https://wiki.python.org/moin/Generators>`_
        instead of returning lists.

    :param category: Category name
    :type category: str
    :return: the list of videos in the category
    :rtype: list
    """
    return VIDEOS[category]


def list_categories():
    """
    Create the list of video categories in the Kodi interface.
    """
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(_handle, 'My Video Collection')
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(_handle, 'videos')
    # Get video categories
    categories = get_categories()
    # Iterate through categories
    for category in categories:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=category)
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({'thumb': VIDEOS[category][0]['thumb'],
                          'icon': VIDEOS[category][0]['thumb'],
                          'fanart': VIDEOS[category][0]['thumb']})
        # Set additional info for the list item.
        # Here we use a category name for both properties for for simplicity's sake.
        # setInfo allows to set various information for an item.
        # For available properties see the following link:
        # https://codedocs.xyz/xbmc/xbmc/group__python__xbmcgui__listitem.html#ga0b71166869bda87ad744942888fb5f14
        # 'mediatype' is needed for a skin to display info for this ListItem correctly.
        list_item.setInfo('video', {'title': category,
                                    'genre': category,
                                    'mediatype': 'video'})
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=listing&category=Movies
        url = get_url(action='listing', category=category)
        # is_folder = True means that this item opens a sub-list of lower level items.
        is_folder = True
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)


def list_videos(category):
    """
    Create the list of playable videos in the Kodi interface.

    :param category: Category name
    :type category: str
    """
    # Set plugin category. It is displayed in some skins as the name
    # of the current section.
    xbmcplugin.setPluginCategory(_handle, category)
    # Set plugin content. It allows Kodi to select appropriate views
    # for this type of content.
    xbmcplugin.setContent(_handle, 'videos')
    # Get the list of videos in the category.
    videos = get_videos(category)
    # Iterate through videos.
    for video in videos:
        # Create a list item with a text label and a thumbnail image.
        list_item = xbmcgui.ListItem(label=video['name'])
        # Set additional info for the list item.
        # 'mediatype' is needed for skin to display info for this ListItem correctly.
        list_item.setInfo('video', {'title': video['name'],
                                    'genre': video['genre'],
                                    'mediatype': 'video'})
        # Set graphics (thumbnail, fanart, banner, poster, landscape etc.) for the list item.
        # Here we use the same image for all items for simplicity's sake.
        # In a real-life plugin you need to set each image accordingly.
        list_item.setArt({'thumb': video['thumb'], 'icon': video['thumb'], 'fanart': video['thumb']})
        # Set 'IsPlayable' property to 'true'.
        # This is mandatory for playable items!
        list_item.setProperty('IsPlayable', 'true')
        # Create a URL for a plugin recursive call.
        # Example: plugin://plugin.video.example/?action=play&video=http://www.vidsplay.com/wp-content/uploads/2017/04/crab.mp4
        url = get_url(action='play', video=video['video'])
        # Add the list item to a virtual Kodi folder.
        # is_folder = False means that this item won't open any sub-list.
        is_folder = False
        # Add our item to the Kodi virtual folder listing.
        xbmcplugin.addDirectoryItem(_handle, url, list_item, is_folder)
    # Add a sort method for the virtual folder items (alphabetically, ignore articles)
    xbmcplugin.addSortMethod(_handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Finish creating a virtual folder.
    xbmcplugin.endOfDirectory(_handle)


def play_video(path):
    """
    Play a video by the provided path.

    :param path: Fully-qualified video URL
    :type path: str
    """
    # Create a playable item with a path to play.
    play_item = xbmcgui.ListItem(path=path)
    # Pass the item to the Kodi player.
    xbmcplugin.setResolvedUrl(_handle, True, listitem=play_item)


def router(paramstring):
    """
    Router function that calls other functions
    depending on the provided paramstring

    :param paramstring: URL encoded plugin paramstring
    :type paramstring: str
    """
    # Parse a URL-encoded paramstring to the dictionary of
    # {<parameter>: <value>} elements
    params = dict(parse_qsl(paramstring))
    # Check the parameters passed to the plugin
    if params:
        if params['action'] == 'listing':
            # Display the list of videos in a provided category.
            list_videos(params['category'])
        elif params['action'] == 'play':
            # Play a video from a provided URL.
            play_video(params['video'])
        else:
            # If the provided paramstring does not contain a supported action
            # we raise an exception. This helps to catch coding errors,
            # e.g. typos in action names.
            raise ValueError('Invalid paramstring: {0}!'.format(paramstring))
    else:
        # If the plugin is called from Kodi UI without any parameters,
        # display the list of video categories
        list_categories()


if __name__ == '__main__':
    # Call the router function and pass the plugin call parameters to it.
    # We use string slicing to trim the leading '?' from the plugin call paramstring
    router(sys.argv[2][1:])
